﻿

**ARCHITECTURE Végétale** conçoit des espaces extérieurs de toutes tailles, 
pour une clientèle essentiellement composée de particuliers et de quelques professionnels situés dans le sillon mosellan, depuis Nancy jusqu’à Luxembourg-Ville.
>**Notre agence France** intervient toutefois pour des clients dans toute La France.
**Notre agence belge** intervient en Wallonie, dans les provinces de Namur et du Luxembourg. 





	


