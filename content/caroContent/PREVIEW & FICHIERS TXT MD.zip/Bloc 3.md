﻿

>  Soucieux d’intégrer le Style Architectural, l’Atelier d’ **ARCHITECTURE Végétale** s’emploie à **faire dialoguer le Jardin avec l’architecture des bâtiments**, le nouvel espace extérieur se dévoile alors **comme une extension végétale** de ceux-ci.




