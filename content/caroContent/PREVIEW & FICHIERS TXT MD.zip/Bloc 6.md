﻿


>  **ARCHITECTURE Végétale** bénéficie d'un réseau large d'experts et de professionnels dans des domaines très divers tels que le Paysage, la Botanique, les métiers du bois et de l'éclairage, la sculpture de métal et bien d'autres encore, pour une mise en relation directe ou indirecte.

