﻿


 **ARCHITECTURE Végétale** est en mesure d’imaginer des projets pour un large éventail d’espaces :


> Quelle que soit **l’échelle du lieu à aménager** :
qu’il s’agisse d’un balcon, une cour, une terrasse, un patio
ou de grands espaces,


>Quelle que soit **la destination du lieu à aménager** :
Qu’il s’agisse d’une **Transformation complète** de votre jardin, 
la **Modification d’une plate-bande** ou bien encore **le Besoin
 de quelques conseils** en vue de changer tout simplement 
 l’ambiance de votre jardin,

**Nous sommes à votre écoute...** 
Chaque projet est pour nous, un nouveau défi.
  






