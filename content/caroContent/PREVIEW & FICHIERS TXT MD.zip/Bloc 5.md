﻿

>  **L’ Atelier associe les palettes végétales aux rythmes différents**, mêle les textures, les formes et les couleurs, intègre quelques fois des structures, y accroche des sentiments et des lumières. 
>  Il nuance, il module, selon vos envies, l’Atelier d’ **ARCHITECTURE Végétale** met en scène les plantes dans votre jardin.

  



